.. _references:

.. only:: html

   References
   **********

.. bibliography:: bibli.bib
   :all:

