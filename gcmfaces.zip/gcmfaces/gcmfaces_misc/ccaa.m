%abbreviation for clear all; close all;
clear all; close all;
