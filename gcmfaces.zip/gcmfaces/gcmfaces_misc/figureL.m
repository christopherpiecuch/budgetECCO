
% figure; set(gcf,'Units','Normalized','Position',[0.1 0.2 0.8 0.8]);
% figure; set(gcf,'Units','Normalized','Position',[0. 0.2 0.4 0.8]);
% figure; set(gcf,'Units','Normalized','Position',[-1.7 0.2 0.8 0.8]);
figure;
