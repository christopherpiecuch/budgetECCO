function dt=getStep(fileName)
% assumes gcmfaces has been instantiated

% if using 12 months of output for 2010 provided on
% jumpdrive under: /eccov4r3_native_grid_netcdf/
ncid = netcdf.open(fileName,'NOWRITE');
dt = diff(24*netcdf.getVar(ncid,netcdf.inqVarID(ncid,'time_bnds'),'double'));
netcdf.close(ncid);

% if using 12 months of output for 2010 but retrieved
% from the full 288 months (1992-2015) of output 
% found at the URL:
%   https://ecco.tacc.utexas.edu/workbench/data-depot/public/ecco.storage.community/ECCO/ECCOv4/Release3
% or 
%   ftp://ecco.jpl.nasa.gov/Version4/Release3/
% under the subdirectories:
%  nctiles_monthly & nctiles_monthly_snapshots
% TO USE UNCOMMENT LINES STARTING %%%%
%%%% ncid = netcdf.open(fileName,'NOWRITE');
%%%% dt = [0 diff(netcdf.getVar(ncid,netcdf.inqVarID(ncid,'timstep'),'double'))'];
%%%% dt = dt(217:228); 
    % during 1992-2015, months 217-228 correspond
    % to the months of the year 2010
%%%% netcdf.close(ncid);

return