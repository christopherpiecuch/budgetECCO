function data=loadEccoCdf2Faces(fileName,varName)
% assumes gcmfaces has been instantiated

% tile parameters
numberTiles=13;
tileFaceNumber=1:numberTiles;
tileX1=[1 1 1 91 91 91 1 181 181 181 271 271 271];
tileX2=tileX1+89;
tileY1=[1 91 181 1 91 181 271 181 91 1 181 91 1];
tileY2=tileY1+89;

% load file
ncid = netcdf.open(fileName,'NOWRITE');
tmpVar = netcdf.getVar(ncid,netcdf.inqVarID(ncid,varName),'double');
netcdf.close(ncid);

if ndims(tmpVar)==4 % 2d field (e.g., SSH)
    for nn=1:numberTiles
        if nn<7 % faces 1 and 2; no rotation
            data(tileX1(nn):tileX2(nn),tileY1(nn):tileY2(nn),:)=squeeze(tmpVar(:,:,nn,:));
        elseif nn==7 % arctic cap face 3; rotation
            data(tileX1(nn):tileX2(nn),tileY1(nn):tileY2(nn),:)=squeeze(rot90(tmpVar(:,:,nn,:)));
        else % nn>7 % faces 4 and 5; rotation
            data(tileX1(nn):tileX2(nn),tileY1(nn):tileY2(nn),:)=squeeze(rot90(rot90(rot90(tmpVar(:,:,nn,:)))));
        end
    end
elseif ndims(tmpVar)==5 % 3d field (e.g., THETA)
    for nn=1:numberTiles
        if nn<7 % faces 1 and 2; no rotation
            data(tileX1(nn):tileX2(nn),tileY1(nn):tileY2(nn),:,:)=squeeze(tmpVar(:,:,:,nn,:));
        elseif nn==7 % arctic cap face 3; rotation
            data(tileX1(nn):tileX2(nn),tileY1(nn):tileY2(nn),:,:)=squeeze(rot90(tmpVar(:,:,:,nn,:)));
        else % nn>7 % faces 4 and 5; rotation
            data(tileX1(nn):tileX2(nn),tileY1(nn):tileY2(nn),:,:)=squeeze(rot90(rot90(rot90(tmpVar(:,:,:,nn,:)))));
        end
    end
else
    error('Invalid number of dimensions.')
end

data=convert2array_llc(data);

%data(data==0)=nan;
return

